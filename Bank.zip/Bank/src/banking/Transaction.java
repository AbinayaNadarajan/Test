package banking;

public interface Transaction {
	void deposit();

	void withdraw();

	void balance();

}
